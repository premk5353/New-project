const user = require("./user.route");
module.exports = {
	user,
};
